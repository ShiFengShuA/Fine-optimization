```json
{
  "title": "粗灰泥楼梯",
  "icon": "suppsquared:daub_stairs",
  "categories": [
    "minecraft:blocks",
    "minecraft:tag/stairs",
    "minecraft:group/building_blocks"
  ],
  "associated_items": [
    "suppsquared:daub_stairs",
    "suppsquared:daub_frame_stairs"
  ]
}
```

&spotlight(suppsquared:daub_stairs)
**粗灰泥楼梯**是[粗灰泥](^supplementaries:daub)的[楼梯](^minecraft:tag/stairs)变种。

;;;;;

&title(Crafting)
<recipe;suppsquared:daub_stairs>
<recipe;suppsquared:daub_frame_stairs>
