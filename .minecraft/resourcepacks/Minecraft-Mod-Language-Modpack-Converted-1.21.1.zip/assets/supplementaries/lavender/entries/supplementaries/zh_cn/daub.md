```json
{
  "title": "粗灰泥",
  "icon": "supplementaries:daub",
  "categories": [
    "minecraft:blocks",
    "minecraft:group/functional_blocks"
  ],
  "associated_items": [
    "supplementaries:daub",
    "supplementaries:daub_frame",
    "supplementaries:daub_brace",
    "supplementaries:daub_cross_brace"
  ]
}
```

&spotlight(supplementaries:daub)
**粗灰泥**是新增的中世纪风格装饰性方块，与[木框架和木支架](^supplementaries:timber_frame)配合很好。


向木框架和木支架中放置粗灰泥后，其便会变成对应的**粗灰泥篱笆装饰方块**。

;;;;;

&title(合成)
<recipe;supplementaries:daub>
<recipe;supplementaries:daub_frame>

;;;;;

&title(合成)
<recipe;supplementaries:daub_brace>
<recipe;supplementaries:daub_cross_brace>
