```json
{
  "title": "黑石灯",
  "icon": "supplementaries:blackstone_lamp",
  "categories": [
    "minecraft:blocks",
    "minecraft:group/functional_blocks",
    "supplementaries:lamps"
  ],
  "associated_items": [
    "supplementaries:blackstone_lamp"
  ]
}
```

&spotlight(supplementaries:blackstone_lamp)
**黑石灯**是[灯](^supplementaries:lamps)的[黑石](^minecraft:blackstone)变种。

;;;;;

&title(合成)
<recipe;supplementaries:blackstone_lamp>