```json
{
  "title": "石灯",
  "icon": "supplementaries:stone_lamp",
  "categories": [
    "minecraft:blocks",
    "minecraft:group/functional_blocks",
    "supplementaries:lamps"
  ],
  "associated_items": [
    "supplementaries:stone_lamp"
  ]
}
```

&spotlight(supplementaries:stone_lamp)
**石灯**是[灯](^supplementaries:lamps)的[石头](^minecraft:stone)变种。

;;;;;

&title(合成)
<recipe;supplementaries:stone_lamp>