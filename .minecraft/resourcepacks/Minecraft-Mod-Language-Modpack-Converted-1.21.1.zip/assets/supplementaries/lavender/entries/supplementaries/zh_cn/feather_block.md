```json
{
  "title": "羽毛块",
  "icon": "supplementaries:feather_block",
  "categories": [
    "minecraft:blocks",
    "minecraft:group/functional_blocks"
  ],
  "associated_items": [
    "supplementaries:feather_block"
  ]
}
```

&spotlight(supplementaries:feather_block)
摔落在**羽毛块**上或在其上行走时，它会散出羽毛粒子，并使得玩家缓慢沉入其中，抵消摔落伤害。

;;;;;

&title(合成)
<recipe;supplementaries:feather_block>
