```json
{
  "title": "加固火把",
  "icon": "supplementaries:sconce",
  "categories": [
    "minecraft:blocks",
    "minecraft:group/functional_blocks"
  ],
  "associated_items": [
    "supplementaries:sconce",
    "supplementaries:sconce_soul",
    "supplementaries:sconce_lever"
  ]
}
```

&spotlight(supplementaries:sconce)
**加固火把**是装饰性物品，能作为火把的替代品。

<block;supplementaries:sconce>

;;;;;

&title(合成)
<recipe;supplementaries:sconce>
<recipe;supplementaries:sconce_soul>

;;;;;

&title(合成)
<recipe;supplementaries:sconce_lever>

;;;;;

&title(用途)
可以用打火石、火焰弹、着火的箭、火药线点燃。


令加固火把含水，或向加固火把投掷喷溅型水瓶可以熄灭它。


不会被水冲毁。
