```json
{
  "title": "错觉术与辑流术",
  "icon": "trickster:mirror_of_evaluation",
  "ordinal": 1,
  "parent": "trickster:tricks"
}
```

错觉术会根据上下文生成值，无需输入。通常作为法术树的叶节点存在。


辑流术会根据输入收集信息。此类戏法与错觉术不同，它们多次执行产生的结果不一定一致。
