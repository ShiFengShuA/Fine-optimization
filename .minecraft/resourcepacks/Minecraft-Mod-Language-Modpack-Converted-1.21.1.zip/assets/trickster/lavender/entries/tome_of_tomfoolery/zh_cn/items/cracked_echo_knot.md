```json
{
  "title": "开裂的回响晶结",
  "icon": "trickster:cracked_echo_knot",
  "category": "trickster:items",
  "required_advancements": [
    "trickster:cracked_echo_knot"
  ],
  "ordinal": 15
}
```

这些[晶结](^trickster:items/knots)出自古老文明的废墟，残破但仍能够使用。它们会以绿宝石晶结的两倍速度自然充能，其容量则是钻石晶结的两倍。

这种晶结还有其他奇特的地方。

;;;;;

当[收据之技巧](^trickster:ploys/message#3)的第二参数为装有此类晶结的槽位时，会出现奇怪的现象。对[派遣之技巧](^trickster:ploys/message#2)进行同样的操作也会产生类似情况⸺似乎有*东西*发生了变化。


这两则技巧术同开裂的回响晶结间的具体交互机制仍未解明。不过，让玩家之外的事物利用此特性的所有尝试都无功而返。
