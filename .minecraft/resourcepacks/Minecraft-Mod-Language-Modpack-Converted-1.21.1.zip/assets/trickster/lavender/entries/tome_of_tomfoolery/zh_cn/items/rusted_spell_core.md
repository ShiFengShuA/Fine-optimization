```json
{
  "title": "生锈法术核心",
  "icon": "trickster:rusted_spell_core",
  "category": "trickster:items",
  "required_advancements": [
    "trickster:rusted_spell_core"
  ],
  "ordinal": 120
}
```

这些[法术核心](^trickster:items/spell_core)老旧而严重磨损，会出现在主世界四处遗落的箱子中。它们与其他法术核心不同，制作时使用的是普通金属，而现如今已经开始生锈了。非常不建议在不做完善准备的情况下使用此类法术核心。
