```json
{
  "title": "常量",
  "icon": "minecraft:bedrock"
}
```

本节的抄绘图案能将绘制处的符记变为字面量。

;;;;;

<|pattern@trickster:templates|pattern=1\,4\,7,title=基础之修订|>

{gray}（抄绘图案）{}

---

将符记换为数“2”。

;;;;;

<|pattern@trickster:templates|pattern=6\,3\,0\,2\,5\,8,title=目录之修订|>

{gray}（抄绘图案）{}

---

将符记换为空列表。

;;;;;

<|pattern@trickster:templates|pattern=2\,5\,8\,6\,3\,0,title=图册之修订|>

{gray}（抄绘图案）{}

---

将符记换为空映射。
