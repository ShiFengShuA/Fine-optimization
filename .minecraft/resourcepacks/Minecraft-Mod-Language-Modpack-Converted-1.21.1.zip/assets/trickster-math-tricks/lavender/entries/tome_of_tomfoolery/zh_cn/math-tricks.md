```json
{
  "title": "数学戏法",
  "icon": "minecraft:quartz",
  "category": "trickster:tricks"
}
```
“戏法师：数学戏法”附属添加了一大把有用的数学戏法，以求*稍稍*简化戏法师中复杂事物的处理过程。


本模组只添加了总计2个戏法及修订术，其余功能都需经过这两者实现。

;;;;;

<|glyph@trickster:templates|trick-id=trickster-math-tricks:math_lib,title=计算之谋略|>

pattern, any... -> any

---

执行给定图案对应的数学戏法。此图案是调用本附属数学戏法的必备步骤。

;;;;;

<|pattern@trickster:templates|pattern=3\,4\,0\,3\,6\,4\,7\,6,title=计算之修订|>

{gray}（抄绘图案）{}

---

运行圆中图案对应的数学修订术。此图案是使用本附属数学修订术的必备步骤。