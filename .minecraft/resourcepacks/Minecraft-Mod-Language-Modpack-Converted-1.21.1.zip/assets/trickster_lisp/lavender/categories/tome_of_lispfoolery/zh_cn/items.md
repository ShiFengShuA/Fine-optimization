```json
{
  "title": "物品",
  "icon": "trickster_lisp:transpiler",
  "ordinal": 0
}
```

转译法术所需的物品。